import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk
import cv2
import face_recognition
import pickle
import pandas as pd
import os
from datetime import datetime
import threading

# Load encodings
ENCODINGS_FILE = "encodings.pkl"
if not os.path.exists(ENCODINGS_FILE):
    raise FileNotFoundError("Encoding file not found. Please run the encoding script first.")

with open(ENCODINGS_FILE, "rb") as f:
    data = pickle.load(f)

# Create attendance directory
os.makedirs("Attendance", exist_ok=True)

# Mark attendance in CSV
def mark_attendance(name):
    date_str = datetime.now().strftime("%Y-%m-%d")
    time_str = datetime.now().strftime("%H:%M:%S")
    filename = f"Attendance/Attendance_{date_str}.csv"

    if os.path.exists(filename):
        df = pd.read_csv(filename)
    else:
        df = pd.DataFrame(columns=["Name", "Time"])

    if name not in df["Name"].values:
        df = pd.concat([df, pd.DataFrame([[name, time_str]], columns=["Name", "Time"])], ignore_index=True)
        df.to_csv(filename, index=False)
        print(f"✅ Marked {name} as present at {time_str}")
    else:
        print(f"ℹ️ {name} already marked as present")

# Display uploaded image in GUI
def show_image_preview(path):
    img = Image.open(path)
    img = img.resize((200, 200))
    photo = ImageTk.PhotoImage(img)
    image_label.configure(image=photo)
    image_label.image = photo  # Prevent garbage collection
    image_label.place(x=150, y=200)

# Image upload and recognition process
def upload_and_check():
    file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.jpeg *.png")])
    if not file_path:
        return

    show_image_preview(file_path)
    progress_bar.place(x=50, y=420)
    progress_bar.start()

    def process_image():
        try:
            image = cv2.imread(file_path)
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            boxes = face_recognition.face_locations(rgb, model="hog")
            encodings = face_recognition.face_encodings(rgb, boxes)

            if not encodings:
                messagebox.showwarning("No Face Detected", "⚠️ No face detected in the uploaded image.")
                return

            matched_names = []

            for encoding in encodings:
                matches = face_recognition.compare_faces(data["encodings"], encoding)
                name = "Unknown"

                face_distances = face_recognition.face_distance(data["encodings"], encoding)
                best_match_index = face_distances.argmin() if face_distances.size > 0 else -1

                if best_match_index != -1 and matches[best_match_index]:
                    name = data["names"][best_match_index]
                    mark_attendance(name)
                else:
                    print("❌ Face not recognized")

                matched_names.append(name)

            if matched_names:
                messagebox.showinfo("Result", f"✅ Attendance Recorded For:\n{', '.join(matched_names)}")
            else:
                messagebox.showinfo("Result", "⚠️ No matching students found.")
        except Exception as e:
            messagebox.showerror("Error", str(e))
        finally:
            progress_bar.stop()
            progress_bar.place_forget()

    threading.Thread(target=process_image).start()

# GUI Setup
root = tk.Tk()
root.title("AI-Based Automated Attendance System")
root.geometry("500x500")
root.configure(bg="#f5f5f5")
root.resizable(False, False)

# Title & Subtitle
title = tk.Label(root, text="Automated Attendance System", font=("Helvetica", 20, "bold"), bg="#f5f5f5", fg="#333")
title.pack(pady=15)

subtitle = tk.Label(root, text="Facial Recognition Powered by AI", font=("Helvetica", 12), bg="#f5f5f5", fg="#666")
subtitle.pack()

# Buttons
upload_button = tk.Button(root, text="📷 Upload Student Image", command=upload_and_check, font=("Arial", 13),
                          bg="#4CAF50", fg="white", padx=20, pady=10)
upload_button.pack(pady=20)

exit_button = tk.Button(root, text="❌ Exit", command=root.destroy, font=("Arial", 12),
                        bg="#f44336", fg="white", padx=15, pady=8)
exit_button.pack()

# Image preview label
image_label = tk.Label(root, bg="#f5f5f5")
image_label.place_forget()  # Initially hidden

# Progress bar
progress_bar = ttk.Progressbar(root, orient=tk.HORIZONTAL, mode='indeterminate', length=400)

# Run GUI
root.mainloop()
