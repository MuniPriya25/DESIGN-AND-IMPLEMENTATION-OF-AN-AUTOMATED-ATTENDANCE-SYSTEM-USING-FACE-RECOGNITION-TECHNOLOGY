import os
import cv2
import face_recognition
import pickle

# Folder where training images are stored
training_dir = "TrainingImages"
known_encodings = []
known_names = []

# Loop through each image in the folder
for filename in os.listdir(training_dir):
    if filename.endswith((".jpg", ".png", ".jpeg")):
        path = os.path.join(training_dir, filename)
        name = os.path.splitext(filename)[0]

        image = cv2.imread(path)
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        boxes = face_recognition.face_locations(rgb, model="hog")
        encodings = face_recognition.face_encodings(rgb, boxes)

        if encodings:
            known_encodings.append(encodings[0])
            known_names.append(name)
        else:
            print(f"❌ No face found in: {filename}")

# Save encodings to a file
data = {"encodings": known_encodings, "names": known_names}
with open("encodings.pkl", "wb") as f:
    pickle.dump(data, f)

print("✅ Encodings saved to encodings.pkl")
